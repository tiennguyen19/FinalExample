package nnt.exam.bai1;

public interface IAnimal {
    public String makeSound();
}

